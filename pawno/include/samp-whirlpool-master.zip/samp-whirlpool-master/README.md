Do not use this.

Use bcrypt: https://github.com/Sreyas-Sreelal/samp-bcrypt/
